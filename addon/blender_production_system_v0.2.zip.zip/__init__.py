bl_info = {
    "name": "Blender Production System",
    "author": "Patrice Newson",
    "version": (0, 1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > BPS",
    "description": (
        "Production auditing, certification, and workflow tools for Blender."
    ),
    "category": "Pipeline",
}

from .operators import audit_operator
from .ui import audit_panel


modules = (
    audit_operator,
    audit_panel,
)


def register():
    for module in modules:
        module.register()


def unregister():
    for module in reversed(modules):
        module.unregister()


if __name__ == "__main__":
    register()
